"""
#-*-coding:utf-8-*- 
# @author: wangyu a beginner programmer, striving to be the strongest.
# @date: 2022/7/7 20:25
"""
import os

# 文件夹路径
#img_path = r'D:/yolo/yolov8/ultralytics-main/dataset/images/train'
# -*- coding: utf-8 -*-
# @Time :
# @Author :
# @Site :  将图片的地址写入到txt中
# @File : jpg2txt.py
# @Software: PyCharm

import os


def writejpg2txt(images_path, txt_name):
    # 打开图片列表清单txt文件
    file_name = open(txt_name, "w")
    # 将路径改为绝对路径
    images_path = os.path.abspath(images_path)
    # 查看文件夹下的图片
    images_name = os.listdir(images_path)

    count = 0
    # 遍历所有文件
    for eachname in images_name:
        # 按照需要的格式写入目标txt文件
        file_name.write(os.path.join(images_path,eachname) + '\n')
        count += 1
    print('生成txt成功！')
    print('{} 张图片地址已写入'.format(count))
    file_name.close()


if __name__ == "__main__":

    # 图片存放目录
    images_path = r'D:/yueyurong/ultralytics_improve - MSDA/ultralytics_improve - MSDA/dataset4/AppleBad/AppleBad/images/train'
    # 生成图片txt文件命名
    txt_name = r'D:/yueyurong/ultralytics_improve - MSDA/ultralytics_improve - MSDA/dataset4/AppleBad/AppleBad/train.txt'
    txt_name = os.path.abspath(txt_name)
    if not os.path.exists(txt_name):
        os.system(r"touch {}".format(txt_name)) #调用系统命令行来创建文件
    #将jpg绝对地址写入到txt中
    writejpg2txt(images_path, txt_name)

